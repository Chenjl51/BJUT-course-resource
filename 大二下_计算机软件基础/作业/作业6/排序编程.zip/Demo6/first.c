#include <stdio.h>

#define len 10
int array1[]={46,74,53,14,26,38,86,65,27,34};
int array2[]={46,74,53,14,26,38,86,65,27,34};
int array3[]={46,74,53,14,26,38,86,65,27,34};

void InsertSort(int a[],int l)
{
    int temp;
    int j;
    printf("直接插入法\n");
    for(int i=1;i<l;i++)
    {
        if(a[i]<a[i-1])
        {
            temp=a[i];
            for(j=i-1;j>=0&&temp<a[j];j--)
            {
                a[j+1]=a[j];
            }
            a[j+1]=temp;

        }
        for(int k=0;k<l;k++)
        {
            printf("%d ",a[k]);
        }
        printf("\n");
    }
}
void PopSort(int a[],int l)
{
    printf("冒泡排序法\n");
    for (int i = 0; i < l - 1; i++) {
        for (int j = 0; j < l - 1 - i; j++) {
            if (a[j] > a[j + 1]) {
                int temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
        for(int k=0;k<l;k++)
        {
            printf("%d ",a[k]);
        }
        printf("\n");
    }
}

void NormalSort(int a[], int l)
{
	int i, j;
	int min; //待排序数组中最小值的下标
	int tmp;
    printf("简单选择排序法\n");
	for (i = 0; i < l - 1; ++i)//i = 0,第一次待排数组为所有数
	{   
		min = i;
		for (j = i + 1; j < l; ++j)
		{
			if (a[j] < a[min])
			{
				min = j;//
			}
		}
		tmp = a[i];
		a[i] = a[min];
		a[min] = tmp;
        for(int k=0;k<l;k++)
        {
            printf("%d ",a[k]);
        }
        printf("\n");
	}
}

int main()
{
    InsertSort(array1,len);
    PopSort(array2,len);
    NormalSort(array3,len);
}